import tempfile
from nisep.data import generate_dataset
def test_synthetic_data():
    with tempfile.TemporaryDirectory() as d:
        t,s,p=generate_dataset(d,missions=5,sequence_length=10,seed=9)
        assert len(s)==15
        assert t.altitude_norm.between(0,1).all()
        assert set(s.recovery_class)<= {"nominal","marginal","unsuccessful"}
        assert len(p)>0
