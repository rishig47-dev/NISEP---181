from nisep.data import load_data
from nisep.evaluate import evaluate_all
t,s,_=load_data("data")
print(evaluate_all(t,s,"artifacts"))
