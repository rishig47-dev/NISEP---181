import json
from nisep.data import load_data
from nisep.quality import validate_telemetry
t, s, p = load_data("data")
print(json.dumps(validate_telemetry(t), indent=2))
print(f"Summary rows: {len(s)} | 3D display points: {len(p)}")
