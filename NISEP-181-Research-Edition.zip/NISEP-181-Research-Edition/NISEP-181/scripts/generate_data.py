import argparse
from nisep.data import generate_dataset
p=argparse.ArgumentParser(); p.add_argument("--missions",type=int,default=2500); p.add_argument("--seed",type=int,default=181)
a=p.parse_args(); generate_dataset("data",a.missions,24,a.seed)
print(f"Generated {a.missions} synthetic missions.")
