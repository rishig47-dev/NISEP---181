import argparse, json
from pathlib import Path
from nisep.data import load_data
from nisep.train import train_sequences,train_cnn,train_recovery
p=argparse.ArgumentParser(); p.add_argument("--epochs",type=int,default=12); a=p.parse_args()
Path("artifacts").mkdir(exist_ok=True)
t,s,_=load_data("data")
r={"sequence_models":train_sequences(t,"artifacts",a.epochs),
   "cnn":train_cnn("artifacts",max(3,a.epochs//2)),
   "recovery":train_recovery(s,"artifacts",a.epochs)}
Path("artifacts/training_summary.json").write_text(json.dumps(r,indent=2))
print(json.dumps(r,indent=2))
