from pathlib import Path
import json
import streamlit as st
from nisep.data import load_data
from nisep.visualization import mission_figure,score_histogram

st.set_page_config(page_title="NISEP-181",page_icon="🛰️",layout="wide")
st.title("🛰️ NISEP-181 | Aerospace Recovery Research Console")
st.caption("Synthetic civilian aerospace recovery simulator")
st.warning("Synthetic research data only. Not a real flight, guidance or landing-control system.")
if not Path("data/mission_summary.csv").exists():
    st.info("Generate data first: `python scripts/generate_data.py --missions 2500 --seed 181`")
    st.stop()
t,s,p=load_data("data")
a,b,c,d=st.columns(4)
a.metric("Synthetic missions",f"{s.mission_id.nunique():,}")
b.metric("Component records",f"{len(s):,}")
c.metric("Telemetry rows",f"{len(t):,}")
d.metric("Mean synthetic score",f"{s.recovery_score.mean():.3f}")
mid=st.selectbox("Select mission",sorted(s.mission_id.unique()))
st.plotly_chart(mission_figure(p,mid),use_container_width=True)
st.subheader("Component assessment")
st.dataframe(s[s.mission_id==mid],use_container_width=True,hide_index=True)
left,right=st.columns(2)
left.plotly_chart(score_histogram(s),use_container_width=True)
right.bar_chart(s.groupby(["component","recovery_class"]).size().unstack(fill_value=0))
st.subheader("Training report")
report=Path("artifacts/training_summary.json")
if report.exists(): st.json(json.loads(report.read_text()))
else: st.info("Train models with `python scripts/train_all.py --epochs 12`.")
