import plotly.graph_objects as go
import plotly.express as px

def mission_figure(paths,mission_id):
    df=paths[paths.mission_id==mission_id]; fig=go.Figure()
    for comp,g in df.groupby("component"):
        g=g.sort_values("point")
        fig.add_trace(go.Scatter3d(x=g.x_display,y=g.y_display,z=g.z_display,
            mode="lines+markers",name=comp,marker={"size":3},line={"width":5}))
    fig.update_layout(title=f"Synthetic mission {mission_id}",
        scene={"xaxis_title":"Display X (abstract)","yaxis_title":"Display Y (abstract)",
               "zaxis_title":"Display Z (abstract)","aspectmode":"cube"},
        margin={"l":0,"r":0,"t":45,"b":0})
    return fig

def score_histogram(summary):
    return px.histogram(summary,x="recovery_score",color="component",nbins=25,
                        barmode="overlay",title="Synthetic recovery-score distribution")
