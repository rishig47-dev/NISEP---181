from pathlib import Path
import json, numpy as np, pandas as pd, torch, joblib
from sklearn.model_selection import GroupShuffleSplit
from sklearn.metrics import mean_absolute_error,mean_squared_error,classification_report,confusion_matrix
from nisep.data import FEATURES,RECOVERY,CONDITION
from nisep.train import sequences,SUM_FEATURES
from models.networks import TelemetryLSTM,TelemetryTransformer,RecoveryMLP

def evaluate_all(telemetry,summary,out):
    out=Path(out); md=out/"metrics"; md.mkdir(parents=True,exist_ok=True); results={}
    X,y,g=sequences(telemetry); _,te=next(GroupShuffleSplit(test_size=.2,n_splits=1,random_state=181).split(X,y,g))
    for name,cls in [("lstm",TelemetryLSTM),("transformer",TelemetryTransformer)]:
        p=out/f"{name}.pt"
        if p.exists():
            model=cls(); model.load_state_dict(torch.load(p,map_location="cpu",weights_only=True)); model.eval()
            with torch.no_grad(): pred=model(torch.tensor(X[te])).numpy()
            results[name]={"MAE":float(mean_absolute_error(y[te],pred)),
                           "RMSE":float(np.sqrt(mean_squared_error(y[te],pred)))}
    p=out/"recovery_mlp.pt"; sp=out/"summary_scaler.joblib"
    if p.exists() and sp.exists():
        xx=summary[SUM_FEATURES].to_numpy(np.float32)
        yr=pd.Categorical(summary.recovery_class,categories=RECOVERY).codes
        yc=pd.Categorical(summary.condition_class,categories=CONDITION).codes
        tr,te=next(GroupShuffleSplit(test_size=.2,n_splits=1,random_state=181).split(xx,yr,summary.mission_id))
        model=RecoveryMLP(); model.load_state_dict(torch.load(p,map_location="cpu",weights_only=True)); model.eval()
        with torch.no_grad(): rp,cp,score=model(torch.tensor(joblib.load(sp).transform(xx[te]),dtype=torch.float32))
        results["recovery"]={"recovery_report":classification_report(yr[te],rp.argmax(1).numpy(),target_names=RECOVERY,output_dict=True,zero_division=0),
            "condition_report":classification_report(yc[te],cp.argmax(1).numpy(),target_names=CONDITION,output_dict=True,zero_division=0),
            "recovery_confusion_matrix":confusion_matrix(yr[te],rp.argmax(1).numpy()).tolist(),
            "condition_confusion_matrix":confusion_matrix(yc[te],cp.argmax(1).numpy()).tolist(),
            "score_MAE":float(mean_absolute_error(summary.recovery_score.to_numpy()[te],score.numpy()))}
    (md/"evaluation.json").write_text(json.dumps(results,indent=2))
    return results
