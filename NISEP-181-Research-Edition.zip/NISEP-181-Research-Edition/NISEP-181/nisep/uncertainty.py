"""Research utilities for prediction uncertainty on synthetic data.

These functions quantify variation across independently trained model predictions.
They are not safety-certified uncertainty estimates.
"""
import numpy as np

def ensemble_summary(predictions):
    """predictions: array [ensemble_members, samples, outputs]."""
    a = np.asarray(predictions, dtype=float)
    if a.ndim < 2 or a.shape[0] < 2:
        raise ValueError("Provide at least two independent model predictions.")
    return {
        "mean": a.mean(axis=0),
        "std": a.std(axis=0, ddof=1),
        "lower_approx_95": a.mean(axis=0) - 1.96 * a.std(axis=0, ddof=1),
        "upper_approx_95": a.mean(axis=0) + 1.96 * a.std(axis=0, ddof=1),
    }

def confidence_label(std_value, low=0.05, medium=0.12):
    """Descriptive uncertainty band; thresholds are illustrative."""
    if std_value < low:
        return "lower model disagreement"
    if std_value < medium:
        return "moderate model disagreement"
    return "high model disagreement"
