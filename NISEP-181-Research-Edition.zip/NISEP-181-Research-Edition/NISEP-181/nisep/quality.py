"""Dataset and output quality checks."""
import pandas as pd

REQUIRED_TELEMETRY = {
    "mission_id", "component", "step", "altitude_norm", "speed_norm",
    "thermal_norm", "vibration_norm", "signal_quality", "event_flag", "anomaly_label"
}

def validate_telemetry(df):
    missing = REQUIRED_TELEMETRY - set(df.columns)
    if missing:
        raise ValueError(f"Missing telemetry columns: {sorted(missing)}")
    if df.empty:
        raise ValueError("Telemetry dataset is empty.")
    for col in ["altitude_norm", "speed_norm", "thermal_norm",
                "vibration_norm", "signal_quality", "event_flag"]:
        if not df[col].between(0, 1).all():
            raise ValueError(f"{col} must be within [0, 1] for this synthetic benchmark.")
    if df.duplicated(["mission_id", "component", "step"]).any():
        raise ValueError("Duplicate mission/component/step records detected.")
    return {"rows": int(len(df)), "missions": int(df.mission_id.nunique()),
            "components": sorted(df.component.unique().tolist()), "valid": True}
