"""Reproducible research experiment helpers."""
from pathlib import Path
import json
import numpy as np
import pandas as pd
from sklearn.model_selection import GroupShuffleSplit
from sklearn.metrics import accuracy_score, f1_score
from nisep.data import FEATURES

def grouped_split(frame, group_col="mission_id", test_size=0.2, seed=181):
    splitter = GroupShuffleSplit(n_splits=1, test_size=test_size, random_state=seed)
    train_idx, test_idx = next(splitter.split(frame, groups=frame[group_col]))
    return frame.iloc[train_idx].copy(), frame.iloc[test_idx].copy()

def telemetry_ablation_report(telemetry, feature_list=None):
    """Descriptive channel statistics to support subsequent ablation experiments."""
    feature_list = feature_list or FEATURES
    rows = []
    for feature in feature_list:
        values = telemetry[feature].to_numpy(dtype=float)
        rows.append({
            "feature": feature,
            "mean": float(np.mean(values)),
            "std": float(np.std(values)),
            "missing_fraction": float(np.mean(~np.isfinite(values))),
            "unique_values": int(pd.Series(values).nunique())
        })
    return pd.DataFrame(rows)

def write_research_manifest(out_dir, seed, missions, epochs, note=None):
    Path(out_dir).mkdir(parents=True, exist_ok=True)
    manifest = {
        "project": "NISEP-181",
        "experiment_seed": int(seed),
        "synthetic_missions": int(missions),
        "training_epochs": int(epochs),
        "data_status": "synthetic and illustrative",
        "research_note": note or "Benchmark scores do not establish real aerospace capability."
    }
    Path(out_dir, "experiment_manifest.json").write_text(json.dumps(manifest, indent=2))
    return manifest
