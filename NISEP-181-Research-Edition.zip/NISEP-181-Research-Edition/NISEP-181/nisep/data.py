from pathlib import Path
import json
import numpy as np
import pandas as pd

FEATURES = ["altitude_norm","speed_norm","thermal_norm","vibration_norm","signal_quality","event_flag"]
COMPONENTS = ["booster","fairing","upper_stage"]
RECOVERY = ["nominal","marginal","unsuccessful"]
CONDITION = ["good","inspect","poor"]

def generate_dataset(out_dir="data", missions=2000, sequence_length=24, seed=181):
    # Entirely synthetic normalized features; not physical flight data.
    out = Path(out_dir); out.mkdir(parents=True, exist_ok=True)
    rng = np.random.default_rng(seed)
    telemetry, summaries, points = [], [], []
    for m in range(missions):
        mid = f"N181-{m:06d}"
        risk = float(rng.beta(2, 3))
        sensor_quality = float(np.clip(rng.normal(.9, .07), .45, 1))
        for ci, comp in enumerate(COMPONENTS):
            t = np.linspace(0, 1, sequence_length)
            alt = np.clip(.15 + .72*np.sin(np.pi*t) + rng.normal(0,.025,len(t)),0,1)
            speed = np.clip(.18 + .62*np.sin(np.pi*t*.78) + rng.normal(0,.035,len(t)),0,1)
            thermal = np.clip(.25 + .48*np.exp(-((t-.45)/.25)**2) + rng.normal(0,.04,len(t)),0,1)
            vib = np.clip(.12 + risk*.25 + rng.normal(0,.06,len(t)),0,1)
            quality = np.clip(sensor_quality + rng.normal(0,.035,len(t)),0,1)
            event = np.zeros(len(t)); event[int(len(t)*.35)] = 1
            anomaly = np.zeros(len(t), dtype=int)
            if rng.random() < .08 + risk*.25:
                k = int(rng.integers(2,len(t)-2)); anomaly[k] = 1
                vib[k] = np.clip(vib[k]+.35,0,1); quality[k] = np.clip(quality[k]-.25,0,1)
            for i in range(len(t)):
                telemetry.append(dict(mission_id=mid,component=comp,step=i,time_norm=t[i],
                    altitude_norm=alt[i],speed_norm=speed[i],thermal_norm=thermal[i],
                    vibration_norm=vib[i],signal_quality=quality[i],event_flag=event[i],
                    anomaly_label=int(anomaly[i])))
            component_risk = float(np.clip(.5*risk+.3*np.mean(vib)+.2*(1-np.mean(quality))+rng.normal(0,.05),0,1))
            rec = rng.choice(RECOVERY,p=np.exp(np.array([2-5*component_risk,.5+component_risk,-.5+4*component_risk]))/np.exp(np.array([2-5*component_risk,.5+component_risk,-.5+4*component_risk])).sum())
            cond = rng.choice(CONDITION,p=np.exp(np.array([2-4*component_risk,.7+component_risk,-.7+3.5*component_risk]))/np.exp(np.array([2-4*component_risk,.7+component_risk,-.7+3.5*component_risk])).sum())
            score = float(np.clip(1-component_risk+rng.normal(0,.08),0,1))
            summaries.append(dict(mission_id=mid,component=comp,mean_altitude=np.mean(alt),
                mean_speed=np.mean(speed),mean_thermal=np.mean(thermal),mean_vibration=np.mean(vib),
                mean_signal_quality=np.mean(quality),anomaly_count=int(anomaly.sum()),
                recovery_score=score,recovery_class=rec,condition_class=cond))
            # Arbitrary normalized points for visualization only, not physical paths.
            u=np.linspace(0,1,30); radius=.15+.12*component_risk
            for j,v in enumerate(u):
                points.append(dict(mission_id=mid,component=comp,point=j,
                    x_display=radius*np.cos(2*np.pi*v)+rng.normal(0,.008),
                    y_display=radius*np.sin(2*np.pi*v)+rng.normal(0,.008),
                    z_display=np.clip(1-v+rng.normal(0,.015),0,1),recovery_score=score))
    pd.DataFrame(telemetry).to_csv(out/"telemetry.csv",index=False)
    pd.DataFrame(summaries).to_csv(out/"mission_summary.csv",index=False)
    pd.DataFrame(points).to_csv(out/"component_observations.csv",index=False)
    (out/"metadata.json").write_text(json.dumps(dict(project="NISEP-181",seed=seed,
        missions=missions,sequence_length=sequence_length,synthetic_only=True),indent=2))
    return load_data(out)

def load_data(out_dir="data"):
    p=Path(out_dir)
    return (pd.read_csv(p/"telemetry.csv"),pd.read_csv(p/"mission_summary.csv"),
            pd.read_csv(p/"component_observations.csv"))
