from pathlib import Path
import numpy as np, pandas as pd, torch, joblib
from torch import nn
from torch.utils.data import DataLoader,TensorDataset
from sklearn.model_selection import GroupShuffleSplit
from sklearn.preprocessing import StandardScaler
from sklearn.metrics import accuracy_score
from nisep.data import FEATURES,RECOVERY,CONDITION
from models.networks import TelemetryLSTM,TelemetryTransformer,TelemetryAutoencoder,ComponentCNN,RecoveryMLP

DEVICE=torch.device("cuda" if torch.cuda.is_available() else "cpu")
SUM_FEATURES=["mean_altitude","mean_speed","mean_thermal","mean_vibration","mean_signal_quality","anomaly_count","recovery_score"]

def sequences(df):
    xs=[]; ys=[]; groups=[]
    for (mid,comp),g in df.groupby(["mission_id","component"]):
        a=g.sort_values("step")[FEATURES].to_numpy(np.float32)
        xs.append(a[:-1]); ys.append(a[-1]); groups.append(mid)
    return np.stack(xs),np.stack(ys),np.array(groups)

def train_sequences(df,out,epochs=10):
    out=Path(out); out.mkdir(parents=True,exist_ok=True)
    X,y,g=sequences(df); tr,va=next(GroupShuffleSplit(test_size=.2,n_splits=1,random_state=181).split(X,y,g))
    xt=torch.tensor(X); yt=torch.tensor(y); results={}
    for name,model in [("lstm",TelemetryLSTM()),("transformer",TelemetryTransformer())]:
        model.to(DEVICE); opt=torch.optim.AdamW(model.parameters(),lr=.001); lossfn=nn.MSELoss()
        loader=DataLoader(TensorDataset(xt[tr],yt[tr]),batch_size=64,shuffle=True)
        for _ in range(epochs):
            model.train()
            for xb,yb in loader:
                xb,yb=xb.to(DEVICE),yb.to(DEVICE); opt.zero_grad()
                loss=lossfn(model(xb),yb); loss.backward(); nn.utils.clip_grad_norm_(model.parameters(),1); opt.step()
        model.eval()
        with torch.no_grad(): pred=model(xt[va].to(DEVICE)).cpu().numpy()
        results[name]={"validation_mae":float(np.abs(pred-y[va]).mean())}
        torch.save(model.cpu().state_dict(),out/f"{name}.pt")
    # Autoencoder: normal synthetic rows only.
    normal=torch.tensor(df[df.anomaly_label==0][FEATURES].to_numpy(np.float32))
    ae=TelemetryAutoencoder().to(DEVICE); opt=torch.optim.Adam(ae.parameters(),lr=.001)
    loader=DataLoader(TensorDataset(normal),batch_size=128,shuffle=True)
    for _ in range(epochs):
        for (xb,) in loader:
            xb=xb.to(DEVICE); opt.zero_grad(); loss=nn.functional.mse_loss(ae(xb),xb); loss.backward(); opt.step()
    torch.save(ae.cpu().state_dict(),out/"autoencoder.pt")
    return results

def synthetic_images(n=1500,size=32,seed=181):
    rng=np.random.default_rng(seed); X=np.zeros((n,1,size,size),np.float32); y=rng.integers(0,3,n)
    yy,xx=np.mgrid[:size,:size]
    for i,k in enumerate(y):
        a=rng.normal(.12,.05,(size,size)); cx=cy=size/2
        if k==0: mask=(abs(xx-cx)<5)&(abs(yy-cy)<12)
        elif k==1: mask=(xx-cx)**2+(yy-cy)**2<100
        else: mask=(abs(xx-cx)<11)&(abs(yy-cy)<3)
        a[mask]+=.65; X[i,0]=np.clip(a+rng.normal(0,.05,a.shape),0,1)
    return X,y

def train_cnn(out,epochs=6):
    X,y=synthetic_images(); ids=np.random.default_rng(181).permutation(len(y)); cut=int(.8*len(y))
    tr,va=ids[:cut],ids[cut:]; model=ComponentCNN().to(DEVICE)
    opt=torch.optim.AdamW(model.parameters(),lr=.001); lossfn=nn.CrossEntropyLoss()
    loader=DataLoader(TensorDataset(torch.tensor(X[tr]),torch.tensor(y[tr],dtype=torch.long)),batch_size=64,shuffle=True)
    for _ in range(epochs):
        for xb,yb in loader:
            xb,yb=xb.to(DEVICE),yb.to(DEVICE); opt.zero_grad(); loss=lossfn(model(xb),yb); loss.backward(); opt.step()
    model.eval()
    with torch.no_grad(): pred=model(torch.tensor(X[va]).to(DEVICE)).argmax(1).cpu().numpy()
    torch.save(model.cpu().state_dict(),Path(out)/"component_cnn.pt")
    return {"validation_accuracy":float(accuracy_score(y[va],pred)),"dataset":"procedural abstract tiles"}

def train_recovery(df,out,epochs=10):
    out=Path(out); out.mkdir(parents=True,exist_ok=True)
    X=df[SUM_FEATURES].to_numpy(np.float32)
    yr=pd.Categorical(df.recovery_class,categories=RECOVERY).codes
    yc=pd.Categorical(df.condition_class,categories=CONDITION).codes
    tr,va=next(GroupShuffleSplit(test_size=.2,n_splits=1,random_state=181).split(X,yr,df.mission_id))
    scaler=StandardScaler().fit(X[tr]); X=scaler.transform(X).astype(np.float32)
    score=df.recovery_score.to_numpy(np.float32)
    model=RecoveryMLP().to(DEVICE); opt=torch.optim.AdamW(model.parameters(),lr=.001)
    loader=DataLoader(TensorDataset(torch.tensor(X[tr]),torch.tensor(yr[tr]),torch.tensor(yc[tr]),torch.tensor(score[tr])),batch_size=64,shuffle=True)
    for _ in range(epochs):
        for xb,rb,cb,sb in loader:
            xb,rb,cb,sb=xb.to(DEVICE),rb.to(DEVICE),cb.to(DEVICE),sb.to(DEVICE)
            opt.zero_grad(); rp,cp,sp=model(xb)
            loss=nn.functional.cross_entropy(rp,rb)+nn.functional.cross_entropy(cp,cb)+.35*nn.functional.mse_loss(sp,sb)
            loss.backward(); opt.step()
    model.eval()
    with torch.no_grad():
        rp,cp,sp=model(torch.tensor(X[va]).to(DEVICE))
    result={"recovery_accuracy":float(accuracy_score(yr[va],rp.argmax(1).cpu())),
            "condition_accuracy":float(accuracy_score(yc[va],cp.argmax(1).cpu())),
            "score_mae":float(torch.abs(sp.cpu()-torch.tensor(score[va])).mean())}
    torch.save(model.cpu().state_dict(),out/"recovery_mlp.pt"); joblib.dump(scaler,out/"summary_scaler.joblib")
    return result
