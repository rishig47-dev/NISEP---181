# NISEP-181 in simple words

Imagine a reusable rocket mission represented inside a computer. After launch, the simulator creates separate records for the booster, payload fairing, and upper stage.

NISEP-181 acts like a digital inspection team:

- LSTM and Transformer: learn patterns in sensor readings over time.
- Autoencoder: flags readings that look different from learned normal synthetic readings.
- CNN: demonstrates image classification on artificial component-like patterns.
- Multi-task neural network: predicts a simulated recovery category and component-condition category.
- 3D viewer: displays illustrative component paths.
- Dashboard: brings the mission records, predictions, and charts together.

The output is a research assessment, not a command to a rocket. The paths and data are synthetic examples, not real rocket physics.
