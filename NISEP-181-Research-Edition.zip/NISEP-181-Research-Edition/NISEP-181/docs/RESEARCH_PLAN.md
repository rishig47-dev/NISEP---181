# Research plan
1. Reproduce baseline metrics with fixed seed 181.
2. Compare LSTM and Transformer MAE across multiple seeds.
3. Increase synthetic sensor noise and measure degradation.
4. Perform channel ablations.
5. Compare autoencoder reconstruction-error distributions for synthetic normal/anomalous rows.
6. Add calibration and uncertainty analysis.
7. Report limitations prominently. Never interpret synthetic benchmark scores as real aerospace capability.

Use mission-grouped train/test splits to reduce leakage between telemetry windows from the same synthetic mission.
