# NISEP-181 — Research-grade upgrade plan

## What raises the research quality

The project is designed around five research pillars:

1. **Multi-model comparison:** LSTM and Transformer sequence forecasting, CNN synthetic-image classification, autoencoder anomaly scoring, and multi-task component assessment.
2. **Reproducibility:** fixed seeds, recorded experiment manifests, configuration files, and mission-grouped data splits.
3. **Uncertainty awareness:** compare independently trained models and report prediction disagreement rather than presenting one prediction as absolute truth.
4. **Robustness:** test sensor noise, missing observations, and synthetic distribution shifts.
5. **Scientific reporting:** report MAE/RMSE, precision/recall/F1, confusion matrices, calibration, ablations, and limitations.

## Important distinction

The current generator uses abstract normalized values and artificial labels. The resulting metrics show how well models learn the generator's rules. They do not prove that the models can recover a real rocket, predict a real landing location, or assess real hardware condition.

## How to perform a defensible research study

- Use separate mission IDs for train, validation, and test.
- Never tune thresholds on the final test set.
- Repeat experiments with several random seeds.
- Compare each deep model against a simple baseline.
- Include confidence intervals and error analysis.
- Document all synthetic assumptions.
- Do not describe illustrative 3D display paths as physical flight trajectories.

## Suggested paper title

"An Uncertainty-Aware Multi-Model Deep Learning Framework for Synthetic Reusable Aerospace Component Health and Recovery Assessment"
