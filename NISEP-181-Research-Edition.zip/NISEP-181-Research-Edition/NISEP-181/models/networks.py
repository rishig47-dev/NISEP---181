import torch
from torch import nn

class TelemetryLSTM(nn.Module):
    def __init__(self, input_dim=6, hidden=64):
        super().__init__()
        self.rnn=nn.LSTM(input_dim,hidden,num_layers=2,batch_first=True,dropout=.1)
        self.head=nn.Sequential(nn.LayerNorm(hidden),nn.Linear(hidden,input_dim),nn.Sigmoid())
    def forward(self,x):
        y,_=self.rnn(x); return self.head(y[:,-1])

class TelemetryTransformer(nn.Module):
    def __init__(self,input_dim=6,hidden=64):
        super().__init__()
        self.proj=nn.Linear(input_dim,hidden)
        layer=nn.TransformerEncoderLayer(hidden,4,hidden*2,batch_first=True,activation="gelu")
        self.encoder=nn.TransformerEncoder(layer,2)
        self.head=nn.Sequential(nn.LayerNorm(hidden),nn.Linear(hidden,input_dim),nn.Sigmoid())
    def forward(self,x):
        return self.head(self.encoder(self.proj(x))[:,-1])

class TelemetryAutoencoder(nn.Module):
    def __init__(self,input_dim=6):
        super().__init__()
        self.enc=nn.Sequential(nn.Linear(input_dim,32),nn.ReLU(),nn.Linear(32,3))
        self.dec=nn.Sequential(nn.Linear(3,32),nn.ReLU(),nn.Linear(32,input_dim),nn.Sigmoid())
    def forward(self,x): return self.dec(self.enc(x))

class ComponentCNN(nn.Module):
    def __init__(self,classes=3):
        super().__init__()
        self.net=nn.Sequential(nn.Conv2d(1,16,3,padding=1),nn.ReLU(),nn.MaxPool2d(2),
            nn.Conv2d(16,32,3,padding=1),nn.ReLU(),nn.MaxPool2d(2),
            nn.Conv2d(32,64,3,padding=1),nn.ReLU(),nn.AdaptiveAvgPool2d(1),
            nn.Flatten(),nn.Linear(64,32),nn.ReLU(),nn.Linear(32,classes))
    def forward(self,x): return self.net(x)

class RecoveryMLP(nn.Module):
    def __init__(self,input_dim=7):
        super().__init__()
        self.shared=nn.Sequential(nn.Linear(input_dim,64),nn.ReLU(),nn.Dropout(.15),
            nn.Linear(64,32),nn.ReLU())
        self.recovery=nn.Linear(32,3); self.condition=nn.Linear(32,3)
        self.score=nn.Sequential(nn.Linear(32,1),nn.Sigmoid())
    def forward(self,x):
        h=self.shared(x); return self.recovery(h),self.condition(h),self.score(h).squeeze(-1)
